package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pages.*;
import utils.WebDriverHolder;

public class AmazonSteps {
    WebDriver driver = WebDriverHolder.getDriver();

    LoginPage loginPage = new LoginPage(driver);
    CartPage cartPage = new CartPage(driver);
    PrePaymentPage prePaymentPage = new PrePaymentPage(driver);

    @Given("User navigates to the Amazon login page")
    public void userNavigatesToAmazonLoginPage() {
        driver.get("https://www.amazon.com/ap/signin");
    }

    @When("User enters {string} and {string}")
    public void userEntersCredentials(String email, String password) {
        loginPage.login(email, password);
    }

    @Then("User validates login {string}")
    public void userValidatesLogin(String loginStatus) {
        boolean isLoggedIn = loginPage.isLoginSuccessful(driver);
        assert loginStatus.equals("success") == isLoggedIn;
    }

    @And("User proceeds to checkout")
    public void userProceedsToCheckout() {
        cartPage.clickProceedToCheckout();
    }

    @And("User selects payment method {string}")
    public void userSelectsPaymentMethod(String method) {
        prePaymentPage.selectPaymentMethod(method);
    }

    @Then("User confirms the payment")
    public void userConfirmsThePayment() {
        prePaymentPage.confirmPayment();
    }
}
