
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.BrowserUtils;

public class LoginPage {
    @FindBy(id = "ap_email")
    private WebElement emailField;

    @FindBy(id = "ap_password")
    private WebElement passwordField;

    @FindBy(id = "signInSubmit")
    private WebElement signInButton;

    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void login(String email, String password) {
        BrowserUtils.sendKeysWithWait(emailField, email);
        BrowserUtils.sendKeysWithWait(passwordField, password);
        signInButton.click();
    }

    public boolean isLoginSuccessful(WebDriver driver) {
        return driver.getTitle().contains("Amazon");
    }
}
