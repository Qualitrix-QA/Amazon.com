package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverHolder {

    private static ThreadLocal<WebDriver> driverThread = new ThreadLocal<>();

    // Getter for WebDriver
    public static WebDriver getDriver() {
        if (driverThread.get() == null) {
            System.setProperty("webdriver.chrome.driver", "/Users/anaikara/Downloads/chromedriver-mac/chromedriver");
            driverThread.set(new ChromeDriver());
        }
        return driverThread.get();
    }

    // Setter for WebDriver
    public static void setDriver(WebDriver driver) {
        driverThread.set(driver);
    }

    // Remove the WebDriver instance
    public static void removeDriver() {
        if (driverThread.get() != null) {
            driverThread.get().quit();
            driverThread.remove();
        }
    }
}