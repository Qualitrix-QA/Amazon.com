package utils;

import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BrowserUtils {

    public static void sendKeysWithWait(WebElement element, String value) {
        try {
            WebDriverWait wait = new WebDriverWait(WebDriverHolder.getDriver(), Duration.ofSeconds(10));
            WebElement visibleElement = wait.until(ExpectedConditions.visibilityOf(element));
            visibleElement.sendKeys(value); // Perform action after ensuring visibility
        } catch (Exception e) {
            System.err.println("Error sending keys: " + e.getMessage());
        }
    }

    public static boolean isElementVisible(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(WebDriverHolder.getDriver(), Duration.ofSeconds(10));
            WebElement visibleElement = wait.until(ExpectedConditions.visibilityOf(element));
            return visibleElement.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public static void clickWithWait(WebElement element) {
        try {
            WebDriverWait wait = new WebDriverWait(WebDriverHolder.getDriver(), Duration.ofSeconds(10));
            WebElement clickableElement = wait.until(ExpectedConditions.elementToBeClickable(element));
            clickableElement.click(); // Perform click after ensuring element is clickable
        } catch (Exception e) {
            System.err.println("Error clicking element: " + e.getMessage());
        }
    }

    public static void selectDropdownOption(WebElement dropdown, String option) {
        try {
            Select select = new Select(dropdown);
            select.selectByVisibleText(option);


        } catch (Exception e) {
            System.err.println("Error selecting dropdown option: " + e.getMessage());
        }
    }
}