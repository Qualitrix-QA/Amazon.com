
package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.BrowserUtils;

public class PrePaymentPage {
    @FindBy(id = "payment-method")
    private WebElement paymentMethodDropdown;

    @FindBy(id = "confirm-payment")
    private WebElement confirmPaymentButton;

    public PrePaymentPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    public void selectPaymentMethod(String method) {
        BrowserUtils.selectDropdownOption(paymentMethodDropdown, method);
    }

    public void confirmPayment() {
        BrowserUtils.clickWithWait(confirmPaymentButton);
    }
}
